#include "bigint.hpp"

bigint::bigint() : _value("0") {}

bigint::bigint(unsigned int n) : _value(std::to_string(n)) {

    if(n == 0)
    {
        _value = "0";
        return;
    }
    while(n > 0)
    {
        _value = std::to_string(n % 10) + _value;
        n /= 10;
    }

}

