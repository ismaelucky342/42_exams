#ifndef BIG_INT_HPP
#define BIG_INT_HPP

#include <string>

class bigint {

    private: 
        std::string _value; 

    public:
        bigint();
        bigint(unsigned int n);


        
}; 


#endif // BIG_INT_HPP
