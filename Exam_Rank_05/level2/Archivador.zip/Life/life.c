#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int c, char **v)
{
	char *b, *t, *s, a;
	int w, h, n, i = 0, j = 0, p = 0, x, y, k, u, r;

	if (c != 4)
		return 1;
	w = atoi(v[1]); h = atoi(v[2]); n = atoi(v[3]);
	b = calloc(w * h, 1); t = calloc(w * h, 1);
	while (read(0, &a, 1) > 0)
	{
		a == 'w' ? i -= i > 0 : a == 'a' ? j -= j > 0 : a == 's' ? i += i < h - 1
			: a == 'd' ? j += j < w - 1 : a == 'x' ? p = !p : 0;
		b[i * w + j] |= p;
	}
	while (n--)
	{
		for (y = 0; y < h; y++)
			for (x = 0; x < w; x++)
			{
				for (k = 0, u = -1; u < 2; u++)
					for (r = -1; r < 2; r++)
						k += (u || r) && y + u >= 0 && y + u < h && x + r >= 0 && x + r < w && b[(y + u) * w + x + r];
				t[y * w + x] = k == 3 || (k == 2 && b[y * w + x]);
			}
		s = b; b = t; t = s;
	}
	for (y = 0; y < h; y++, putchar('\n'))
		for (x = 0; x < w; x++)
			putchar(b[y * w + x] ? 'O' : ' ');
	free(b); free(t);
}